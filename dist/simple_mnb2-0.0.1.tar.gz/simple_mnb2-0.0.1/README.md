# simple_mnb
Given training data in BOW format, trains a simple multinomial Naive Bayes classifier
